CREATE DATABASE membership_form;

USE membership_form;

CREATE TABLE members (
    id INT AUTO_INCREMENT PRIMARY KEY,
    school_name VARCHAR(255) NOT NULL,
    class VARCHAR(50) NOT NULL,
    section VARCHAR(50),
    photograph VARCHAR(255) NOT NULL,
    full_name VARCHAR(255) NOT NULL,
    birth_date DATE NOT NULL,
    gender ENUM('Male', 'Female', 'Others') NOT NULL,
    nationality VARCHAR(100) NOT NULL,
    aadhar_number CHAR(12) NOT NULL UNIQUE,
    email VARCHAR(255),
    submission_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
